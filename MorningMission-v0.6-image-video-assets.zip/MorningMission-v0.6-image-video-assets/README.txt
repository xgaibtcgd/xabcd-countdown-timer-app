Morning Mission v0.6 — Image and Video Assets

Included in this ZIP:
- images/app_drawable_nodpi/: bundled app image assets used by the Android project
- images/design_mockups/: concept and visual target images used during design

Video assets:
- There are no standalone video files in v0.6.
- Character motion/celebration behavior is implemented as in-app animation logic rather than MP4/GIF video files.

If you also want the audio assets, they are in the project under:
app/src/main/res/raw/
